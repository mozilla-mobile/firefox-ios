module Fastlane
  module Applivery
    VERSION = "2.2.0"
  end
end
